const message = 'Hello world' //

const list= ["apple","mango","banana"] 

for(let i=0; i<list.length; i++){
  console.log(list[i])
}

function sum(){
  let sum=0;

  for (let i=1; i<=100; i++){
    sum += i;
  }
  return sum;
}
// Update header text
document.querySelector('#header').innerHTML = message

// Log to console
console.log(message)
console.log(list)

const result=sum();
console.log(result);

